from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import sqlite3, json, mimetypes, os, threading, webbrowser
from datetime import datetime, date, timedelta

ROOT = Path(__file__).resolve().parent
INSTALL_ROOT = ROOT.parent
PUBLIC = ROOT / 'public'
DATA = Path(os.environ.get('ATELIER_DATA_DIR', str(INSTALL_ROOT / 'data')))
DB_PATH = DATA / 'atelier.db'
HOST = '127.0.0.1'
PORT = 8765

DATA.mkdir(exist_ok=True)

SCHEMA = '''
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  event_date TEXT NOT NULL,
  start_time TEXT,
  end_time TEXT,
  all_day INTEGER NOT NULL DEFAULT 0,
  category TEXT NOT NULL DEFAULT 'general',
  location TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  contact TEXT DEFAULT '',
  url TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'planned',
  recurrence TEXT NOT NULL DEFAULT 'none',
  show_in_month INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  due_date TEXT,
  due_time TEXT,
  notes TEXT DEFAULT '',
  completed INTEGER NOT NULL DEFAULT 0,
  archived INTEGER NOT NULL DEFAULT 0,
  important INTEGER NOT NULL DEFAULT 0,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL CHECK(entity_type IN ('event','task')),
  entity_id INTEGER NOT NULL,
  title TEXT DEFAULT '',
  remind_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  snoozed_until TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date);
CREATE INDEX IF NOT EXISTS idx_tasks_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_reminders_time ON reminders(remind_at);
'''

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys = ON')
    return c

with conn() as c:
    c.executescript(SCHEMA)
    cols = {r['name'] for r in c.execute('PRAGMA table_info(reminders)').fetchall()}
    if 'title' not in cols:
        c.execute("ALTER TABLE reminders ADD COLUMN title TEXT DEFAULT ''")
        c.commit()


def now_iso():
    return datetime.now().replace(microsecond=0).isoformat()

def rowdict(row):
    return dict(row) if row else None

def expand_events(rows, start_s, end_s):
    try:
        start = date.fromisoformat(start_s)
        end = date.fromisoformat(end_s)
    except Exception:
        return [dict(r) for r in rows]
    out = []
    for r in rows:
        e = dict(r)
        base = date.fromisoformat(e['event_date'])
        recur = e.get('recurrence') or 'none'
        if recur == 'none':
            if start <= base <= end:
                e['instance_date'] = e['event_date']
                e['series_id'] = e['id']
                out.append(e)
            continue
        d = base
        # advance quickly enough for normal local use
        while d < start:
            if recur == 'daily': d += timedelta(days=1)
            elif recur == 'weekly': d += timedelta(days=7)
            elif recur == 'monthly':
                y = d.year + (1 if d.month == 12 else 0)
                m = 1 if d.month == 12 else d.month + 1
                day = min(d.day, [31,29 if y%4==0 and (y%100!=0 or y%400==0) else 28,31,30,31,30,31,31,30,31,30,31][m-1])
                d = date(y,m,day)
            else: break
        guard = 0
        while d <= end and guard < 500:
            ee = dict(e)
            ee['instance_date'] = d.isoformat()
            ee['series_id'] = e['id']
            out.append(ee)
            if recur == 'daily': d += timedelta(days=1)
            elif recur == 'weekly': d += timedelta(days=7)
            elif recur == 'monthly':
                y = d.year + (1 if d.month == 12 else 0)
                m = 1 if d.month == 12 else d.month + 1
                day = min(d.day, [31,29 if y%4==0 and (y%100!=0 or y%400==0) else 28,31,30,31,30,31,31,30,31,30,31][m-1])
                d = date(y,m,day)
            else: break
            guard += 1
    return out

class Handler(BaseHTTPRequestHandler):
    server_version = 'AtelierLocal/0.0.6'

    def log_message(self, fmt, *args):
        print('[Atelier]', fmt % args)

    def _json(self, data, status=200):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _body(self):
        n = int(self.headers.get('Content-Length', '0') or 0)
        if not n: return {}
        try: return json.loads(self.rfile.read(n).decode('utf-8'))
        except Exception: return {}

    def _serve_static(self, path):
        rel = 'index.html' if path in ('','/') else path.lstrip('/')
        target = (PUBLIC / rel).resolve()
        if PUBLIC.resolve() not in target.parents and target != PUBLIC.resolve():
            self.send_error(403); return
        if not target.exists() or not target.is_file():
            target = PUBLIC / 'index.html'
        data = target.read_bytes()
        ctype = mimetypes.guess_type(str(target))[0] or 'application/octet-stream'
        self.send_response(200)
        self.send_header('Content-Type', ctype + ('; charset=utf-8' if ctype.startswith('text/') or ctype.endswith('javascript') else ''))
        self.send_header('Content-Length', str(len(data)))
        self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path); p = u.path; q = parse_qs(u.query)
        if not p.startswith('/api/'):
            return self._serve_static(p)
        if p == '/api/version':
            version_file = ROOT / 'VERSION'
            version = version_file.read_text(encoding='utf-8').strip() if version_file.exists() else '0.0.5'
            return self._json({'version': version})
        with conn() as c:
            if p == '/api/events':
                start = q.get('start', ['1900-01-01'])[0]; end = q.get('end', ['2100-12-31'])[0]
                rows = c.execute('SELECT * FROM events WHERE event_date <= ? ORDER BY event_date,start_time,id', (end,)).fetchall()
                return self._json(expand_events(rows, start, end))
            if p == '/api/tasks':
                rows = c.execute('SELECT * FROM tasks WHERE archived=0 ORDER BY completed, important DESC, COALESCE(due_date,\'9999-12-31\'), order_index, id').fetchall()
                return self._json([dict(r) for r in rows])
            if p == '/api/reminders':
                rows = c.execute('''
                    SELECT r.*,
                      CASE WHEN r.entity_type='event' THEN (SELECT title FROM events WHERE id=r.entity_id)
                           ELSE (SELECT title FROM tasks WHERE id=r.entity_id) END AS entity_title
                    FROM reminders r
                    WHERE r.status != 'done'
                    ORDER BY COALESCE(r.snoozed_until,r.remind_at),r.id
                ''').fetchall()
                return self._json([dict(r) for r in rows])
            if p == '/api/reminders/due':
                now = q.get('now', [now_iso()])[0]
                rows = c.execute('''
                    SELECT r.*, 
                      CASE WHEN r.entity_type='event' THEN (SELECT title FROM events WHERE id=r.entity_id)
                           ELSE (SELECT title FROM tasks WHERE id=r.entity_id) END AS entity_title
                    FROM reminders r
                    WHERE r.status='pending' AND COALESCE(r.snoozed_until,r.remind_at) <= ?
                    ORDER BY COALESCE(r.snoozed_until,r.remind_at), r.id
                ''', (now,)).fetchall()
                return self._json([dict(r) for r in rows])
        return self._json({'error':'not found'},404)

    def do_POST(self):
        u = urlparse(self.path); p = u.path; body = self._body(); ts = now_iso()
        if p == '/api/version':
            version_file = ROOT / 'VERSION'
            version = version_file.read_text(encoding='utf-8').strip() if version_file.exists() else '0.0.5'
            return self._json({'version': version})
        with conn() as c:
            if p == '/api/events':
                vals = (
                    body.get('title','').strip(), body.get('event_date'), body.get('start_time') or None, body.get('end_time') or None,
                    1 if body.get('all_day') else 0, body.get('category','general'), body.get('location',''), body.get('notes',''),
                    body.get('contact',''), body.get('url',''), body.get('status','planned'), body.get('recurrence','none'),
                    1 if body.get('show_in_month', True) else 0, ts, ts)
                if not vals[0] or not vals[1]: return self._json({'error':'title and event_date required'},400)
                cur=c.execute('''INSERT INTO events(title,event_date,start_time,end_time,all_day,category,location,notes,contact,url,status,recurrence,show_in_month,created_at,updated_at)
                                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',vals)
                eid=cur.lastrowid
                for ra in body.get('reminders',[]) or []:
                    if isinstance(ra, str): ra = {'remind_at': ra, 'title': ''}
                    when = (ra or {}).get('remind_at')
                    if when: c.execute('INSERT INTO reminders(entity_type,entity_id,title,remind_at,status,created_at) VALUES(?,?,?,?,?,?)',('event',eid,(ra or {}).get('title',''),when,'pending',ts))
                c.commit(); return self._json({'id':eid},201)
            if p == '/api/tasks':
                title=body.get('title','').strip()
                if not title: return self._json({'error':'title required'},400)
                oi=c.execute('SELECT COALESCE(MAX(order_index),0)+1 n FROM tasks').fetchone()['n']
                cur=c.execute('''INSERT INTO tasks(title,due_date,due_time,notes,completed,archived,important,order_index,created_at,updated_at)
                                 VALUES(?,?,?,?,0,0,?,?,?,?)''',(title,body.get('due_date') or None,body.get('due_time') or None,body.get('notes',''),1 if body.get('important') else 0,oi,ts,ts))
                tid=cur.lastrowid
                for ra in body.get('reminders',[]) or []:
                    if isinstance(ra, str): ra = {'remind_at': ra, 'title': ''}
                    when = (ra or {}).get('remind_at')
                    if when: c.execute('INSERT INTO reminders(entity_type,entity_id,title,remind_at,status,created_at) VALUES(?,?,?,?,?,?)',('task',tid,(ra or {}).get('title',''),when,'pending',ts))
                c.commit(); return self._json({'id':tid},201)
        return self._json({'error':'not found'},404)

    def do_PUT(self):
        u=urlparse(self.path); p=u.path; body=self._body(); ts=now_iso(); parts=p.strip('/').split('/')
        with conn() as c:
            if len(parts)==3 and parts[0]=='api' and parts[1]=='events':
                eid=int(parts[2]); old=c.execute('SELECT * FROM events WHERE id=?',(eid,)).fetchone()
                if not old: return self._json({'error':'not found'},404)
                d=dict(old); d.update(body)
                c.execute('''UPDATE events SET title=?,event_date=?,start_time=?,end_time=?,all_day=?,category=?,location=?,notes=?,contact=?,url=?,status=?,recurrence=?,show_in_month=?,updated_at=? WHERE id=?''',
                          (d['title'],d['event_date'],d.get('start_time') or None,d.get('end_time') or None,1 if d.get('all_day') else 0,d.get('category','general'),d.get('location',''),d.get('notes',''),d.get('contact',''),d.get('url',''),d.get('status','planned'),d.get('recurrence','none'),1 if d.get('show_in_month',1) else 0,ts,eid))
                if 'reminders' in body:
                    c.execute("DELETE FROM reminders WHERE entity_type='event' AND entity_id=? AND status!='done'",(eid,))
                    for ra in body.get('reminders',[]) or []:
                        if isinstance(ra, str): ra = {'remind_at': ra, 'title': ''}
                        when = (ra or {}).get('remind_at')
                        if when: c.execute('INSERT INTO reminders(entity_type,entity_id,title,remind_at,status,created_at) VALUES(?,?,?,?,?,?)',('event',eid,(ra or {}).get('title',''),when,'pending',ts))
                c.commit(); return self._json({'ok':True})
            if len(parts)==3 and parts[0]=='api' and parts[1]=='tasks':
                tid=int(parts[2]); old=c.execute('SELECT * FROM tasks WHERE id=?',(tid,)).fetchone()
                if not old: return self._json({'error':'not found'},404)
                d=dict(old); d.update(body)
                c.execute('''UPDATE tasks SET title=?,due_date=?,due_time=?,notes=?,completed=?,archived=?,important=?,order_index=?,updated_at=? WHERE id=?''',
                          (d['title'],d.get('due_date') or None,d.get('due_time') or None,d.get('notes',''),1 if d.get('completed') else 0,1 if d.get('archived') else 0,1 if d.get('important') else 0,int(d.get('order_index') or 0),ts,tid))
                if 'reminders' in body:
                    c.execute("DELETE FROM reminders WHERE entity_type='task' AND entity_id=? AND status!='done'",(tid,))
                    for ra in body.get('reminders',[]) or []:
                        if isinstance(ra, str): ra = {'remind_at': ra, 'title': ''}
                        when = (ra or {}).get('remind_at')
                        if when: c.execute('INSERT INTO reminders(entity_type,entity_id,title,remind_at,status,created_at) VALUES(?,?,?,?,?,?)',('task',tid,(ra or {}).get('title',''),when,'pending',ts))
                c.commit(); return self._json({'ok':True})
            if len(parts)==4 and parts[0]=='api' and parts[1]=='reminders':
                rid=int(parts[2]); action=parts[3]
                if action=='done':
                    c.execute("UPDATE reminders SET status='done' WHERE id=?",(rid,)); c.commit(); return self._json({'ok':True})
                if action=='finish':
                    rem=c.execute('SELECT * FROM reminders WHERE id=?',(rid,)).fetchone()
                    if not rem: return self._json({'error':'not found'},404)
                    if rem['entity_type']=='task':
                        c.execute("UPDATE tasks SET completed=1,updated_at=? WHERE id=?",(ts,rem['entity_id']))
                    elif rem['entity_type']=='event':
                        c.execute("UPDATE events SET status='done',updated_at=? WHERE id=?",(ts,rem['entity_id']))
                    c.execute("UPDATE reminders SET status='done' WHERE id=?",(rid,))
                    c.commit(); return self._json({'ok':True})
                if action=='snooze':
                    val=body.get('snoozed_until')
                    if not val: return self._json({'error':'snoozed_until required'},400)
                    c.execute("UPDATE reminders SET status='pending',snoozed_until=? WHERE id=?",(val,rid)); c.commit(); return self._json({'ok':True})
        return self._json({'error':'not found'},404)

def make_server():
    # 8765 est le port habituel. Si un ancien processus l'utilise encore,
    # on essaie automatiquement les ports suivants au lieu de planter.
    last_error = None
    for port in range(PORT, PORT + 11):
        try:
            return ThreadingHTTPServer((HOST, port), Handler), port
        except OSError as exc:
            last_error = exc
    raise last_error or OSError('Aucun port local disponible')


if __name__ == '__main__':
    version_file = ROOT / 'VERSION'
    version = version_file.read_text(encoding='utf-8').strip() if version_file.exists() else '0.0.5'
    pid_file = DATA / 'server.pid'
    port_file = DATA / 'server.port'

    try:
        server, active_port = make_server()
    except Exception as exc:
        print(f"[ERREUR] Impossible de demarrer le serveur local : {exc}")
        raise SystemExit(1)

    url = f"http://{HOST}:{active_port}/"
    try:
        pid_file.write_text(str(os.getpid()), encoding='ascii')
        port_file.write_text(str(active_port), encoding='ascii')
    except Exception:
        pass

    print(f"L'Atelier {version} : {url}")
    print("Le navigateur va s'ouvrir automatiquement.")
    print("Ferme cette fenetre pour arreter le serveur.")

    if os.environ.get('ATELIER_NO_BROWSER') != '1':
        timer = threading.Timer(0.6, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            server.server_close()
        except Exception:
            pass
        for f in (pid_file, port_file):
            try:
                f.unlink(missing_ok=True)
            except Exception:
                pass
